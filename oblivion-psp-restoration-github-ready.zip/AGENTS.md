# Agent / contributor instructions

This is **not** the source code of the original PSP game. It is a metadata analysis and targeted patch toolkit.

1. Read `README.md`, `docs/START_HERE.md`, `docs/TEST_PLAN.md` before making changes.
2. Do not claim to have run the game or compiled an original PSP executable unless execution evidence exists. Python checks and binary hashes do not substitute for playtesting.
3. Never commit/upload original or modified ISO/CSO/IMG files, commercial executables, extracted GR.ARC, textures, sounds or other proprietary assets. Work locally with user's authorized original copies and share only original tooling or minimal delta patches.
4. Before changing an ISO patch, verify the input hash, original field bytes, destination field bytes, output length and output hash. Refuse to overwrite the original.
5. Make small, documented changes; add tests where possible. Preserve `data/build_inventory.json` as the original baseline.
6. Prioritize a real PPSSPP playtest of the Anticlere demo -> Zone 2 exit, then Zone 2 -> Zone 3, then the Rhalta gate/Sigil Stone sequence and save/reload.
7. Separate observed facts, static metadata, hypotheses, and proposed fan-created content in all reports.
8. Avoid unverified build automation that claims to compile/playtest a copyrighted game; use unit tests only until a reproducible test environment is configured.
