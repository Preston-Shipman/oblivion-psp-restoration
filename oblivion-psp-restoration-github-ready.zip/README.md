# Oblivion PSP Restoration — Research and Patch Toolkit

An independent, preservation-oriented research and patching workspace for the unreleased **The Elder Scrolls Travels: Oblivion** PSP prototypes. This repository starts from an archived progress kit, not a complete engine source tree or a finished game.

## Current state

- **Base for first targeted experiment:** February 1, 2007 prototype disc image.
- **Verified offline:** Original ISO metadata inspection, single-field patch generation, hash checks reported by the preceding audit.
- **Not yet verified:** Launching the modified image in PPSSPP or on a real PSP Go, successful movement into Anticlere Zone 2, continued exit to Zone 3, quests or save persistence.
- **Known missing content:** At least one referenced zone (`DaggerfallOb_T11`) does not appear in the inspected inventories.
- **No original game ISO, executable, or asset data is distributed here.**

See [full research notes](docs/START_HERE.md), [test checklist](docs/TEST_PLAN.md), and [next development tasks](docs/ROADMAP.md).

## Layout

```text
docs/       Original findings, roadmap and gameplay test plan
tools/      Original Python ISO inventory/patch utility
patches/    Tiny BPS patch for a specific February 1 prototype ISO
data/       Inventory of six prototype disc images (metadata only)
tests/      Automated checks that do not need copyrighted game data
```

## Apply the existing test patch

Use a legally obtained, matching February 1 prototype disc image. Confirm SHA-256 `36c3017920b5e3acef56274fb009e693a66c3f194799dd8605edff9ea9f3b28d` before patching.

```bash
python3 tools/oblivion_psp.py patch /path/to/iND-TESTO010207.iso --output /path/to/Oblivion_Anticlere_Test.iso
```

Expected patched SHA-256: `af8c7551a4e1c70a449a15598f589e201a48c2b0d3b62d3b827679304bdff954`.

Or use `patches/Anticlere_Continuation_Feb01.bps` with a BPS patcher. **Never upload the resulting ISO.**

To inventory an unmodified ISO:

```bash
python3 tools/oblivion_psp.py inspect /path/to/iND-TESTO010207.iso > /tmp/february_inventory.json
```

## Run local checks

```bash
python3 -m unittest discover -s tests -v
```

These tests validate the patch structure and metadata only; they do **not** play the game.

## Continuity for AI coding assistants

Start with [AGENTS.md](AGENTS.md), then [the test plan](docs/TEST_PLAN.md). Make changes through reviewable commits or pull requests, preserve reproducible SHA-256 evidence, and label every in-game claim **untested** until it has device/emulator evidence.

## Rights

This is an unofficial fan research effort. The Elder Scrolls and related works belong to their respective rights holders. Do not add proprietary ISOs, executable images, extracted assets, or source code without permission. A private GitHub repo does not grant redistribution rights.
