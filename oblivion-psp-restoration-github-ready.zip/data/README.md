# Data

`build_inventory.json` is the metadata-only output of the preceding six-disc analysis. It includes names, hashes, offsets, exits, resource counts, and spawns. It is not extracted game content or a playable build. Keep the baseline unchanged for comparisons.
