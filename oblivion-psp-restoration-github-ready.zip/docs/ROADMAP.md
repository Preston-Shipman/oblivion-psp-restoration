# Restoration roadmap

## Priority 0 — preserve and prove

- Keep the original ZIP and build inventories immutable.
- Add automated patch/inventory unit tests, preserve hashes, and document tool versions.
- Perform in-game Anticlere transition playtests on PPSSPP (then PSP Go); log results and any crashes.

## Priority 1 — make one complete chapter

- Reproduce and trace the `rhalta_7` gate activation (`Gate_Open`) from normal play.
- Verify the `RhaltaOb_8` Sigil Stone reward fires once and returns the player to `Hub_5`.
- Check quest status, inventory and save/reload persistence.

## Priority 2 — expand traversal

- Investigate `AnticlereOb_1` transition event `Goto_AnticlereOb_2` and mismatched destination `GlenpointOb_2`.
- Analyze `DaggerfallOb_5` -> missing `DaggerfallOb_T11`: locate source, assess safe substitution, or design clearly differentiated fan-authored content.
- Compare April demo conversation/quest resources with February IDs and dependencies before attempting transfer.

## Priority 3 — author missing gameplay

- Establish a repeatable, rights-respecting asset workflow and editor/patch format. Build or recover only content for which legal permission exists.
- Add documented scripted objectives, enemy behavior and progression chapter-by-chapter.
- Test every change for original PSP memory/performance limits.

**Do not equate number of discovered zone or quest resources with actual percentage of playable campaign completion.**
