# The Elder Scrolls Travels — Oblivion for PSP

## Start with February 1, 2007

The February disc is the best starting point for a fan-finished campaign on an original PSP Go. It contains the native PSP executable, 58 numbered zones, six alternate demo zones and eight test rooms. Rhalta already has a prison escape, an invasion, a Sigil Stone and a return to the hub in the authored data. A complete playthrough of that sequence remains to be demonstrated.

I found compiled game data, including quest and conversation resources. The inspected files contain no complete engine source tree, build project or level editor. Finishing Climax’s full planned story would require creating some of the missing game. The first achievable target is a Rhalta chapter with an opening, a reward, and a save that survives a restart.

## Try the Anticlere exit

1. Extract **iND-TESTO010207.iso** from the February 1 archive you supplied. Keep that original available for comparison.
2. Apply **Anticlere_Continuation_Feb01.bps** to the extracted ISO with a BPS patcher and save the result as **Oblivion_Anticlere_Test.iso**. One option is [Rom Patcher JS](https://www.marcrobledo.com/RomPatcher.js/).
3. Open the resulting ISO in PPSSPP. On a PSP Go already set up to run your prototype ISOs, use the same launch method as for your working original.
4. Once in a level, look in the pause menu for **JUMP TO ANTICLERE DEMO**. The February menu data binds that button to the demo zone. You can also reach it from the courtyard exit in the demo Mages Guild. Walk through the outgoing exit in the Anticlere demo. The stock disc points to the opening prison. The test disc points to Anticlere Zone 2, spawn 1.
5. A successful test means the new area loads, your character can move, and the next exit toward Zone 3 works. For a visual reference, load regular Anticlere Zone 2 separately from the original build’s level selector. Its internal scene name is `TestingGrounds`. Verify first in PPSSPP, then repeat on the Go. Record which device and exit succeed or freeze. Neither version of that test was run during this audit.

**Offline patch option.** With Python 3.7 or newer, place the February ISO beside the extracted kit files. Run the command below from that directory. Windows users with the Python launcher can replace `python3` with `py -3`. The tool writes a separate ISO beside the input and verifies the expected output digest.

```sh
python3 oblivion_psp.py patch "iND-TESTO010207.iso"
```

## What the exit patch changes

The authoring data records the same exit event, `Zone2_1`, in both versions of Anticlere’s first zone. The regular version leads to `Anticlere_2`, spawn `1`. The demo sends the same event to `Rhalta_1_Demo`, spawn `1`. The patch copies the regular destination into the demo door. An area trigger emits that event and the target map contains the named player spawn. Zone 2 also has an exit record for Zone 3.

The BPS changes 14 bytes in one 16-byte destination field at ISO offset `0x042566E0`. The resulting ISO has the same size as its source. I applied the change, independently checked the BPS operations and CRCs against the output, and parsed the resulting ISO again. Only the `Anticlere_1_Demo` archive member differs. This verifies a data edit. In-game loading, quest state and save persistence still need playtesting.

| Image | Bytes | SHA-256 |
| --- | ---: | --- |
| Original February 1 ISO | 247,054,336 | `36c3017920b5e3acef56274fb009e693a66c3f194799dd8605edff9ea9f3b28d` |
| Anticlere test ISO | 247,054,336 | `af8c7551a4e1c70a449a15598f589e201a48c2b0d3b62d3b827679304bdff954` |

## The six builds

| Disc date | Archive members | Zone objects found | Quest / conversation resources in the shared Quests bundle |
| --- | ---: | --- | ---: |
| June 9, 2006 | 64 | 2 early demo zones, Prison and Crypt | No separate bundle |
| November 21, 2006 | 126 | 56 numbered zones and 5 test rooms | 4 / 0 |
| January 11, 2007 | 137 | 58 numbered zones, 6 demo variants and 7 test rooms | 16 / 28 |
| January 31, 2007 | 138 | 58 numbered zones, 6 demo variants and 8 test rooms | 16 / 28 |
| February 1, 2007 | 138 | 58 numbered zones, 6 demo variants and 8 test rooms | 16 / 28 |
| April 27, 2007 | 87 | 3 demo zones, one in Rhalta and two in Anticlere | 20 / 30 |

Zone counts come from packaged streams that instantiate a `CZone` object. A zone can be a blockout or use recycled geometry. Quest and conversation counts are resource blocks. A block can contain several definitions, and some blocks contain explicit test quests. These counts measure what survived on disc. They cannot establish a campaign completion percentage.

The February numbered zones break down into 15 Rhalta, 12 Anticlere, 11 Glenpoint, 8 hub, 7 Moonguard and 5 Daggerfall. Several of those are separate Oblivion-plane zones. All five Daggerfall streams use the `DaggerfallOb_` prefix. The three April demos are `Demo2_Rhalta_3`, `Demo3_Anticlere_1a` and `Demo3_Anticlere_1b`. April has useful dialogue, journal data and encounter work to compare, but moving those resources into February requires testing their identifiers and dependencies.

For January 11, use the ZIP’s **USER_L0.IMG** as the disc image. Its game executable is in **PSP_GAME/SYSDIR/BOOT.BIN**. The other five supplied disc images carry their game ELF in **EBOOT.BIN**. The February ISO’s own creation date is February 1. RetroAchievements lists the same date and its recorded PSP hash matches the supplied copy.

## The Rhalta chapter

- **Prison and gate.** The regular `rhalta_7` zone contains a physical gate trigger. It listens for `Gate_Open`, emits `EndLevel` and names `RhaltaOb_1` as its destination. The map contains Zurul conversation events and enemy-wave counters. The published achievement set records players reaching a gate they cannot enter there. Reproduce the stall from an ordinary playthrough and trace the gate-enable event before changing the destination.
- **Sigil Stone and return.** In `RhaltaOb_8`, the Dremora’s death event is tied to the pickup area. Its relay gives the player the `SIGIL_STONE`, signals the quest task and requests the transition to `Hub_5`. This is a specific end-to-end objective to restore and test. A pass requires the gate to open through play, the reward to fire once, and a reload at the hub to preserve the completed quest and inventory.
- **A genuine content gap.** The outward exit in `DaggerfallOb_5` requests `DaggerfallOb_T11`. None of the six archive directories contains a zone by that name. That branch needs an identified substitute, recovered content, or fan-authored work.
- **A second repair candidate.** In `AnticlereOb_1`, an area emits `Goto_AnticlereOb_2`, but its receiving trigger names `GlenpointOb_2`. Both maps exist. That mismatch merits a separate playtest.

## Inspect another copy

```sh
python3 oblivion_psp.py inspect "iND-TESTO010207.iso" > february_inventory.json
```

**build_inventory.json** already contains results for all six original disc images. For each one it lists the disc hash, archive members, member hashes and offsets, zone exit events, destination names and player-spawn names. An existing destination and spawn establish a link in the data. Quest flags, collision volumes, jump menus and scripted transitions can affect what a player can reach.

## Historical checks

The February hash and achievement list give an independent baseline for the unmodified game, including the prison escape, a Mages Guild delivery and some working cross-zone transitions. [Supported build hash](https://retroachievements.org/game/18043/hashes) · [Documented objectives](https://retroachievements.org/game/18043)

Hidden Palace identifies April as a focused demo. Unseen64’s development history describes a much larger design, including more than 180 planned quests. [April preservation notes](https://hiddenpalace.org/The_Elder_Scrolls_Travels:_Oblivion_(Apr_27,_2007_prototype)) · [Development history](https://www.unseen64.net/2009/09/12/the-elder-scrolls-travels-oblivion-psp-cancelled/)
