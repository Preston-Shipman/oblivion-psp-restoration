# First playable experiment: Anticlere exit

**Status:** Not playtested in the exported kit. No emulator/hardware results are present.

## Preconditions

- A clean February 1, 2007 ISO with SHA-256 `36c3017920b5e3acef56274fb009e693a66c3f194799dd8605edff9ea9f3b28d`.
- The included BPS patch or `tools/oblivion_psp.py patch`.
- PPSSPP, and optionally a real PSP Go set up to run the original prototype.

## Test procedure

1. Produce `Oblivion_Anticlere_Test.iso` locally and verify SHA-256 `af8c7551a4e1c70a449a15598f589e201a48c2b0d3b62d3b827679304bdff954`.
2. Boot in PPSSPP and note version/platform/settings; compare clean vs patched image.
3. In an active level, select **JUMP TO ANTICLERE DEMO** in pause menu, or use Mages Guild courtyard access described in the source research.
4. Enter outgoing doorway of the Anticlere demo and confirm it loads `Anticlere_2` at spawn `1`, not the opening prison.
5. Confirm player movement, collision and camera operation.
6. Follow the outgoing Zone 2 exit to Zone 3 and record result.
7. Repeat on physical PSP Go if available.
8. Record freeze/crash/logs, screenshots (for local issue evidence only), and the original ISO baseline results.

## Report template

- Date / tester:
- Platform (PPSSPP version or PSP Go firmware):
- Original ISO SHA-256:
- Patched ISO SHA-256:
- Boot: PASS / FAIL / NOT TESTED
- Demo entry: PASS / FAIL / NOT TESTED
- Anticlere Zone 2 load: PASS / FAIL / NOT TESTED
- Movement after transition: PASS / FAIL / NOT TESTED
- Zone 2 -> Zone 3: PASS / FAIL / NOT TESTED
- Save and reload: PASS / FAIL / NOT TESTED
- Expected vs actual and logs:

No passage should be marked PASS based solely on metadata.
