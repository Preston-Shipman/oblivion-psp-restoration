# Patches

`Anticlere_Continuation_Feb01.bps` is a 52-byte delta patch for exactly the February 1 prototype ISO identified in the root README. Apply it only to a matching user-supplied original disc. It changes a demo exit destination; in-game behavior remains unverified.
