"""Lightweight offline assertions. These do not execute PSP game code."""
import hashlib
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class KitTests(unittest.TestCase):
    def test_patch_file_signature_and_hash(self):
        data = (ROOT / 'patches/Anticlere_Continuation_Feb01.bps').read_bytes()
        self.assertTrue(data.startswith(b'BPS1'))
        self.assertEqual(len(data), 52)
        self.assertEqual(hashlib.sha256(data).hexdigest(), '9333cbcebd9edf93b4b0d25c88eecb2d4489647d9948db2321087c66cfa2df4d')

    def test_inventory_contains_all_six_versions(self):
        inv = json.loads((ROOT / 'data/build_inventory.json').read_text())
        self.assertEqual(sorted(inv), ['2006-06-09', '2006-11-21', '2007-01-11', '2007-01-31', '2007-02-01', '2007-04-27'])
        self.assertEqual(inv['2007-02-01']['image_sha256'], '36c3017920b5e3acef56274fb009e693a66c3f194799dd8605edff9ea9f3b28d')

    def test_tool_has_expected_patch_guards(self):
        text = (ROOT / 'tools/oblivion_psp.py').read_text()
        for symbol in ('FEB_SHA', 'TEST_SHA', 'OLD_FIELD', 'NEW_FIELD', 'write_test_image'):
            self.assertIn(symbol, text)
        self.assertIn('output.open("xb")', text)

if __name__ == '__main__':
    unittest.main()
