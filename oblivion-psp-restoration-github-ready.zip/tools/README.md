# Tools

`oblivion_psp.py`: original exported offline Python utility. `inspect` scans supported image archives and emits JSON; `patch` writes a separate exact-hash-verified Anticlere test ISO. Python >=3.7, standard library only.
