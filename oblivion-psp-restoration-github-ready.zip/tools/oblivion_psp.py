#!/usr/bin/env python3
"""Inspect the six Oblivion PSP disc images or make the February Anticlere test ISO."""
import argparse
import collections
import hashlib
import json
import mmap
import struct
from pathlib import Path

SECTOR = 2048
GR_PATH = "PSP_GAME/USRDIR/GR.ARC"
FEB_SHA = "36c3017920b5e3acef56274fb009e693a66c3f194799dd8605edff9ea9f3b28d"
TEST_SHA = "af8c7551a4e1c70a449a15598f589e201a48c2b0d3b62d3b827679304bdff954"
DESTINATION_OFFSET = 0x42566E0
OLD_FIELD = b"Rhalta_1_Demo\x00\xbf\xbf"
NEW_FIELD = b"Anticlere_2\x00" + b"\xbf" * 4


def require(condition, message):
    if not condition:
        raise ValueError(message)


def u32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def c_string(value):
    return value.split(b"\0", 1)[0].decode("ascii")


def disc_files(disc):
    """Read single-extent ISO 9660 directory records from these six discs."""
    volume = 16 * SECTOR
    require(disc[volume:volume + 7] == b"\x01CD001\x01",
            "Use the extracted ISO or January 11 USER_L0.IMG.")
    require(struct.unpack_from("<H", disc, volume + 128)[0] == SECTOR,
            "Unsupported sector size.")
    files = {}
    visited = set()

    def walk(record, parent):
        start = u32(record, 2) * SECTOR
        end = start + u32(record, 10)
        require(start not in visited and end <= len(disc), "Invalid ISO directory.")
        visited.add(start)
        pos = start
        while pos < end:
            length = disc[pos]
            if length == 0:
                pos = (pos // SECTOR + 1) * SECTOR
                continue
            require(length >= 34 and pos + length <= end, "Invalid directory record.")
            entry = disc[pos:pos + length]
            pos += length
            name = entry[33:33 + entry[32]]
            if name in (b"\x00", b"\x01"):
                continue
            path = parent + name.decode("ascii").split(";", 1)[0]
            if entry[25] & 2:
                walk(entry, path + "/")
                continue
            offset, size = u32(entry, 2) * SECTOR, u32(entry, 10)
            require(not entry[25] & 0x80 and offset + size <= len(disc),
                    "Unsupported or truncated ISO file.")
            require(path not in files, "Duplicate ISO path.")
            files[path] = (offset, size)

    walk(disc[volume + 156:volume + 190], "")
    require(GR_PATH in files, "Missing Oblivion GR.ARC.")
    return files


def archive_directory(archive):
    """The June format stores payload offsets relative to its data area."""
    modern = archive[:4] == b"A2.0"
    header = 4 if modern else 0
    count, data_start, names, names_size = struct.unpack_from("<4I", archive, header)
    require(header + 16 + count * 16 <= data_start <= names and
            names + names_size <= len(archive), "Invalid archive directory.")
    entries = {}
    for i in range(count):
        name_offset, offset, size, flags = struct.unpack_from(
            "<4I", archive, header + 16 + 16 * i)
        require(name_offset < names_size and flags == 0, "Unsupported archive entry.")
        name_end = archive.find(b"\0", names + name_offset, names + names_size)
        require(name_end >= 0, "Unterminated archive member name.")
        name = archive[names + name_offset:name_end].decode("ascii")
        if not modern:
            offset += data_start
        require(data_start <= offset <= names and size <= names - offset,
                "Invalid archive payload extent.")
        require(name not in entries, "Duplicate archive member.")
        entries[name] = (offset, size)
    return entries


def chunks(stream):
    pos = 0
    while pos < len(stream):
        kind, size, _version = struct.unpack_from("<III", stream, pos)
        start = pos + 12
        if kind == 0x1300:
            # These hub commands carry an explicit byte count for the trailing name.
            size = 8 + u32(stream, start + 4)
        require(start + size <= len(stream), "Truncated scene chunk.")
        yield kind, start, start + size
        pos = start + size


def entity(stream, start, end):
    """Read the behavior class and its tagged attributes from a 0x704 packet."""
    pos = start + 4
    kind = None
    namespace = None
    fields = {}
    while pos + 4 <= end:
        length = u32(stream, pos)
        if length == 0:
            break
        require(8 <= length <= end - pos, "Invalid entity attribute.")
        command = u32(stream, pos + 4)
        value = stream[pos + 8:pos + length]
        if command == 0x20000000:
            kind = c_string(value)
        elif command == 0x80000000:
            namespace = c_string(value)
        elif command < 0x01000000:
            fields[namespace, command] = value
        pos += length
    return kind, fields


def scene_data(stream, name):
    if stream[:4] != b"\x1c\x07\x00\x00":
        return None
    declarations = stream[12:12 + u32(stream, 4)]
    if b"CZone\0" not in declarations:
        return None
    spawns = []
    exits = []
    has_zone = False
    for kind, start, end in chunks(stream):
        if kind != 0x704:
            continue
        behavior, fields = entity(stream, start, end)
        if behavior == "CZone":
            has_zone = True
        elif behavior == "CPlayerSpawner":
            marker = c_string(fields.get(("CBaseBehaviour", 0), b""))
            spawns.append(marker)
        elif behavior == "ZoneTrigger":
            exits.append({
                "destination": c_string(fields.get((behavior, 0), b"")),
                "spawn": c_string(fields.get((behavior, 1), b"")),
                "event": c_string(fields.get((behavior, 2), b"")),
            })
    if not has_zone:
        return None
    role = "numbered zone"
    if name.startswith(("CharTest", "CombatTest")):
        role = "test room"
    elif "demo" in name.lower():
        role = "demo variant"
    elif name in ("1_1_Prison", "1_2_Crypt"):
        role = "June demo zone"
    return {"name": name, "role": role, "spawn_names": spawns, "exit_records": exits}


def quest_resources(stream):
    counts = collections.Counter()
    for kind, start, end in chunks(stream):
        if kind != 0x716:
            continue
        # Resource descriptor: padded name, 16-byte identifier, padded type name.
        offset = start + 8 + u32(stream, start + 4) + 16
        require(offset + 4 <= end, "Invalid resource descriptor.")
        length = u32(stream, offset)
        require(offset + 4 + length <= end, "Invalid resource type.")
        counts[c_string(stream[offset + 4:offset + 4 + length])] += 1
    return dict(sorted(counts.items()))


def inspect_image(image):
    with image.open("rb") as source, mmap.mmap(source.fileno(), 0, access=mmap.ACCESS_READ) as disc:
        files = disc_files(disc)
        offset, size = files[GR_PATH]
        archive = disc[offset:offset + size]
        entries = archive_directory(archive)
        members, scenes, resources = [], [], {}
        for name, (pos, length) in entries.items():
            payload = archive[pos:pos + length]
            members.append({"name": name, "archive_offset": pos, "bytes": length,
                            "sha256": hashlib.sha256(payload).hexdigest()})
            if name == "Quests":
                resources = quest_resources(payload)
            scene = scene_data(payload, name)
            if scene is not None:
                scenes.append(scene)
        by_name = {scene["name"].lower(): scene for scene in scenes}
        for scene in scenes:
            for route in scene["exit_records"]:
                target = by_name.get(route["destination"].lower())
                route["destination_in_disc"] = bool(target) if route["destination"] else None
                route["named_spawn_in_target"] = (
                    route["spawn"] in target["spawn_names"] if target and route["spawn"] else None)
        executables = []
        for filename in ("PSP_GAME/SYSDIR/BOOT.BIN", "PSP_GAME/SYSDIR/EBOOT.BIN"):
            if filename in files:
                pos, length = files[filename]
                executables.append({"path": filename, "bytes": length,
                                    "magic_hex": disc[pos:pos + 4].hex(),
                                    "sha256": hashlib.sha256(disc[pos:pos + length]).hexdigest()})
        return {"image": image.name, "image_bytes": len(disc),
                "image_sha256": hashlib.sha256(disc).hexdigest(),
                "disc_file_count": len(files), "game_executables": executables,
                "archive_format": "A2.0" if archive[:4] == b"A2.0" else "June layout",
                "archive_iso_offset": offset, "archive_bytes": size,
                "archive_sha256": hashlib.sha256(archive).hexdigest(), "members": members,
                "quest_bundle_resource_counts": resources, "zones": scenes}


def write_test_image(image, output):
    """Write a separate, hash-checked ISO. An existing output is never overwritten."""
    with image.open("rb") as source, mmap.mmap(source.fileno(), 0, access=mmap.ACCESS_READ) as disc:
        require(hashlib.sha256(disc).hexdigest() == FEB_SHA,
                "This patch requires the exact unmodified February 1 disc image.")
        start = DESTINATION_OFFSET
        end = start + len(OLD_FIELD)
        require(disc[start:end] == OLD_FIELD, "Unexpected original exit field.")
        with output.open("xb") as dest:
            try:
                with memoryview(disc) as view:
                    digest = hashlib.sha256()
                    for part in (view[:start], NEW_FIELD, view[end:]):
                        dest.write(part)
                        digest.update(part)
                    del part
                require(digest.hexdigest() == TEST_SHA, "Patched image checksum mismatch.")
                dest.flush()
            except BaseException:
                dest.close()
                output.unlink()
                raise
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="command", required=True)
    scan = subs.add_parser("inspect", help="Print the asset inventory and zone exits as JSON")
    scan.add_argument("image", type=Path, help="Uncompressed ISO or January 11 USER_L0.IMG")
    patch = subs.add_parser("patch", help="Create a new February Anticlere test ISO")
    patch.add_argument("image", type=Path)
    patch.add_argument("--output", type=Path, help="New file path, defaults to beside the input")
    args = parser.parse_args()
    try:
        if args.command == "inspect":
            print(json.dumps(inspect_image(args.image), indent=2))
        else:
            output = args.output or args.image.with_name("Oblivion_Anticlere_Test.iso")
            print("Created", write_test_image(args.image, output))
            print("SHA-256", TEST_SHA)
    except (ValueError, OSError, struct.error) as exc:
        parser.exit(1, f"{exc}\n")


if __name__ == "__main__":
    main()
